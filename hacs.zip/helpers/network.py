"""Verify network."""
from socket import gaierror
from integrationhelper import Logger


def internet_connectivity_check(host="api.github.com"):
    """Verify network connectivity."""
    return True
